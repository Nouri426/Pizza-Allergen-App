from tkinter import *

class LetsEatAllergenfreeApp:
  def __init__(self, master):
    master.title("Va Bene Pizzeria")
    message_label = Label(master, text="WELCOME, LET'S EAT ALLERGEN FREE!")
    message_label.pack()
    ingredients_button = Button(master, text="GET HEALTHY INGREDIENTS", command=self.view_manual)
    ingredients_button.pack()
    create_button = Button(master, text="CREATE YOUR OWN", command= self.add_ingredient)
    create_button.pack()
    manual_button = Button(master, text="USER MANUAL", command=self.open_manual)
    manual_button.pack()

  def view_manual(self):
    view_manual_window = Toplevel()
    view_manual_window.title("View Manual")

  def add_ingredient(self):
    add_ingredient_window = Toplevel()
    add_ingredient_window.title("Add Ingredient")

  def open_manual(self):
    manual_window = Toplevel()
    manual_window.title("User Manual")

root = Tk()
app = LetsEatAllergenfreeApp(root)

root.mainloop()







